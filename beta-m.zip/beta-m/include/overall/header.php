<!DOCTYPE html>
<html>
<?php require_once'include/head.php'; ?>
<body>
<?php require_once'include/menu.php'; ?>
<?php require_once'include/jumbotron.php'; ?>

<div class="container">