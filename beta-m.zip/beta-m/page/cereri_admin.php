<?php
$general->protect_login();

if (!$_GET['create']) {
	if (!$_GET['view']) {
		if ($general->server_admin() != true) {
?>
<a href="cereri-admin&create=1" class="btn btn-success btn-md" style="margin: 10px;float: right;">New</a>
<?php } ?>
<table class="table table-hover">
	<thead>
		<tr>
			<th>Name</th>

			<th>
				<i class="ace-icon fa fa-clock-o bigger-110 hidden-480"></i>
				Time
			</th>
			<th>
				Raspunsuri
			</th>
			<th>
				Status
			</th>
			<th>
				Action
			</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($cereri->select_all_application() as $r) { ?>
		<tr>
			<td>
				<a href="profile&name=<?php echo $r['username']; ?>">
					<?php echo $r['username']; ?>
				</a>
			</td>
			<td><?php echo date('d/m/Y - H:i:s', $r['time_create']); ?></td>
			<td><?php echo '7/10'; ?></td>
			<td><?php echo $r['status']; ?></td>
			<td>
				<a href="cereri-admin&view=<?php echo $r['id']; ?>">
					<?php echo 'View'; ?>
				</a>
			</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
<?php } else { ?>
	<div class="border-secondary" style="width:25%;border-bottom-right-radius: 30px;border-top-left-radius: 30px; margin: 10px;float: left;">
		<div class="card-header" style="border-top-left-radius: 30px;">
			<?php echo '<center>PLAYER INFO</center>' ?>
		</div>
		<div class="card-body">
			<?php echo 'Nickname: <a href="profile&name='.$cereri->get_username_from_apply_id($_GET['view']).'">'.$cereri->get_username_from_apply_id($_GET['view']).'</a><br>'; ?>
			<?php echo 'Access: '.$general->get_user_access($general->get_user_access_from_name($cereri->get_username_from_apply_id($_GET['view']))).'.<br>'; ?>
			<?php echo 'Account type: ';user_type($general->get_user_type_from_name($cereri->get_username_from_apply_id($_GET['view'])));echo'.<br>'; ?>
			<?php echo 'Warns: '.$general->get_user_warns_from_name($cereri->get_username_from_apply_id($_GET['view'])).'.<br>'; ?>
			<?php echo 'Other application: '.$cereri->check_application_history($cereri->get_username_from_apply_id($_GET['view'])).'.<br>'; ?>
		</div>
	</div>
	<div class="border-secondary" style="width:65%;border-bottom-right-radius: 30px;border-top-left-radius: 30px; margin: 10px;float: right;">
		<div class="card-header" style="border-top-left-radius: 30px;">
			<?php echo 'APPLICATION DETAILS' ?>
		</div>
		<div class="card-body">
			<?php echo 'Nume: <span class="red">'.$cereri->get_q1_from_apply_id($_GET['view']).'</span><br>'; ?>
			<?php echo 'Varsta: <span class="red">'.$cereri->get_q2_from_apply_id($_GET['view']).'</span><br>'; ?>
			<?php echo 'Ai citit regulamentul?: <span class="red">'.$cereri->get_q3_from_apply_id($_GET['view']).'</span><br>'; ?>
			<?php echo 'Consideri ca poti activa cel putin 2h/zi?: <span class="red">'.$cereri->get_q4_from_apply_id($_GET['view']).'</span><br>'; ?>
			<?php echo 'Care este comanda pentru a bana un jucator cu ID-ul "312"?: <span class="red">'.$cereri->get_q5_from_apply_id($_GET['view']).'</span><br>'; ?>
		</div>
	</div>
	<div class="border-secondary" style="width:65%;border-bottom-right-radius: 30px;border-top-left-radius: 30px; margin: 10px;float: right;">
		<div class="card-header" style="border-top-left-radius: 30px;">
			<?php echo 'APPLICATION COMMENT' ?>
		</div>
		<div class="card-body">
			<div class="border-secondary" style="width: 100%;margin-bottom: 10px;">
				<div class="card-body">
					<p class="card-text">
						[pro]<a href="profile&name=admin"><?php echo 'admin'; ?></a>:
						Some quick example text to build on the card title and make up the bulk of the card's content.
					</p>
				</div>
			</div>
			<form method="post">
				<div class="form-group">
					<label>Application vote.</label><br>
					<input type="radio" id="pro" name="new_admin_request_vote" value="pro">
					<label for="pro">pro</label>
					<input type="radio" id="contra" name="new_admin_request_vote" value="contra" checked>
					<label for="contra">contra</label>
				</div>
				<div class="form-group">
					<textarea class="form-control" placeholder="Leave a comment..." name="new_admin_request_comment"></textarea>
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-danger" name="new_admin_request_comment_btn">Comenteaza</button>
				</div>
			</form>
		</div>
	</div>
<?php } } else { ?>
<form method="post">
	<fieldset>
		<div class="form-group">
			<label for="name">Nume</label>
			<input type="text" class="form-control" id="name" placeholder="Enter your name..." name="new_admin_request_name">
		</div>
		<div class="form-group">
			<label for="age">Varsta</label>
			<input type="text" class="form-control" id="age" placeholder="Enter your age..." name="new_admin_request_age">
		</div>
		<div class="form-group">
			<label>Ai citit regulamentul?</label><br>
			<input type="radio" id="Yes" name="new_admin_request_q1" value="Yes">
			<label for="Yes">Yes</label><br>
			<input type="radio" id="No" name="new_admin_request_q1" value="No" checked>
			<label for="No">No</label>
		</div>
		<div class="form-group">
			<label>Consideri ca poti activa cel putin 2h/zi?</label><br>
			<input type="radio" id="yes" name="new_admin_request_q2" value="Yes">
			<label for="yes">Yes</label><br>
			<input type="radio" id="no" name="new_admin_request_q2" value="No" checked>
			<label for="no">No</label>
		</div>
		<div class="form-group">
			<label>Care este comanda pentru a bana un jucator cu ID-ul "312"?</label><br>
			<input type="radio" id="ans1" name="new_admin_request_q3" value='amx_ban #312 0 "wall"'>
			<label for="ans1">amx_ban #312 0 "wall"</label><br>
			<input type="radio" id="ans2" name="new_admin_request_q3" value='amx_ban 312 0 "wall"' checked>
			<label for="ans2">amx_ban 312 0 "wall"</label><br>
			<input type="radio" id="ans3" name="new_admin_request_q3" value='Nu poti bana pe ID'>
			<label for="ans3">Nu poti bana pe ID</label>
		</div>
		<div class="form-group">
			<button type="submit" class="btn btn-success" name="new_admin_request_btn">Aplica</button>
		</div>
	</fieldset>
</form>
<?php } ?>